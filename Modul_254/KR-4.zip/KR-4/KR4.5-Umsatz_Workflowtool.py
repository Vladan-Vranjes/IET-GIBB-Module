import tkinter as tk
from tkinter import messagebox
 
# Dummy-Datenbank für Benutzer und Produkte
users = {'admin': 'password'}
products = {'1': 'Produkt 1', '2': 'Produkt 2'}
 
logged_in_user = None
 
def login():
    global logged_in_user
    username = entry_username.get()
    password = entry_password.get()
    if username in users and users[username] == password:
        logged_in_user = username
        messagebox.showinfo("Login", "Login successful!")
        show_dashboard()
    else:
        messagebox.showerror("Login", "Invalid username or password")
 
def logout():
    global logged_in_user
    logged_in_user = None
    show_login()
 
def release_product():
    if not logged_in_user:
        messagebox.showerror("Error", "Unauthorized")
        return
    product_id = entry_product_id.get()
    if product_id in products:
        # Beispiel: Produktfreigabelogik
        release_status = True  # Hier setzen Sie die Logik zur Produktfreigabe ein
        messagebox.showinfo("Product Release", f"Product {product_id} released successfully!")
    else:
        messagebox.showerror("Error", "Product not found")
 
def show_login():
    frame_dashboard.pack_forget()
    frame_login.pack()
 
def show_dashboard():
    frame_login.pack_forget()
    frame_dashboard.pack()
 
app = tk.Tk()
app.title("Product Release Tool")
 
# Login Frame
frame_login = tk.Frame(app)
tk.Label(frame_login, text="Username:").pack(pady=5)
entry_username = tk.Entry(frame_login)
entry_username.pack(pady=5)
tk.Label(frame_login, text="Password:").pack(pady=5)
entry_password = tk.Entry(frame_login, show='*')
entry_password.pack(pady=5)
tk.Button(frame_login, text="Login", command=login).pack(pady=20)
 
# Dashboard Frame
frame_dashboard = tk.Frame(app)
tk.Label(frame_dashboard, text="Dashboard").pack(pady=5)
tk.Label(frame_dashboard, text="Welcome!").pack(pady=5)
tk.Label(frame_dashboard, text="Product ID:").pack(pady=5)
entry_product_id = tk.Entry(frame_dashboard)
entry_product_id.pack(pady=5)
tk.Button(frame_dashboard, text="Release Product", command=release_product).pack(pady=20)
tk.Button(frame_dashboard, text="Logout", command=logout).pack(pady=5)
 
show_login()
 
app.mainloop()