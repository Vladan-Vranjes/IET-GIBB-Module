import tkinter as tk
from tkinter import messagebox, ttk

# Funktion zum Speichern der Daten in eine Datei
def save_data():
    incident_ticket = incident_entry.get()
    spezifikation_feature = spezifikation_feature_entry.get()
    security_issue = "Yes" if security_var.get() else "No"
    contact_option = contact_option_var.get()
    additional_info = additional_info_entry.get()
    
    product_ready = product_ready_var.get()
    test_prepared = test_prepared_var.get()
    product_released = product_released_var.get()
    knowledge_transfer = knowledge_transfer_var.get()
    date = date_entry.get()
    
    with open("Output.txt", "a") as file:
        file.write(f"Incident Ticket: {incident_ticket}\n")
        file.write(f"Spezifikation Feature: {spezifikation_feature}\n")
        file.write(f"Security Issue: {security_issue}\n")
        file.write(f"Contact Option: {contact_option}\n")
        file.write(f"Additional Information: {additional_info}\n")
        file.write(f"Product Ready: {product_ready}\n")
        file.write(f"Test Prepared: {test_prepared}\n")
        file.write(f"Product Released: {product_released}\n")
        file.write(f"Knowledge Transfer: {knowledge_transfer}\n")
        file.write(f"Date: {date}\n")
        file.write("\n")

    messagebox.showinfo("Info", "Data saved successfully")

# Funktion zum Wechseln zwischen den Seiten
def show_frame(frame):
    frame.tkraise()

# Initialisieren des Hauptfensters
root = tk.Tk()
root.title("Incident Management Process")
root.geometry("600x600")
root.configure(bg='#f0f0f0')

# Erstellen der Frames für die verschiedenen Seiten
frame1 = tk.Frame(root, bg='#f0f0f0')
frame2 = tk.Frame(root, bg='#f0f0f0')
frame3 = tk.Frame(root, bg='#f0f0f0')

for frame in (frame1, frame2, frame3):
    frame.grid(row=0, column=0, sticky='nsew')

# Frame 1: Incident Management
tk.Label(frame1, text="Incident Ticket:", bg='#f0f0f0').grid(row=0, column=0, padx=10, pady=10)
incident_entry = tk.Entry(frame1, width=30)
incident_entry.grid(row=0, column=1, padx=10, pady=10)

tk.Label(frame1, text="Spezifikation Feature:", bg='#f0f0f0').grid(row=1, column=0, padx=10, pady=10)
spezifikation_feature_entry = tk.Entry(frame1, width=30)
spezifikation_feature_entry.grid(row=1, column=1, padx=10, pady=10)

security_var = tk.BooleanVar()
tk.Checkbutton(frame1, text="Security Issue?", bg='#f0f0f0', variable=security_var).grid(row=2, columnspan=2, pady=10)

tk.Label(frame1, text="Contact Option:", bg='#f0f0f0').grid(row=3, column=0, padx=10, pady=10)
contact_option_var = tk.StringVar()
contact_option_menu = ttk.Combobox(frame1, textvariable=contact_option_var, state="readonly")
contact_option_menu['values'] = ("Problem Management", "Executive Management", "Specialized Team")
contact_option_menu.grid(row=3, column=1, padx=10, pady=10)

tk.Label(frame1, text="Additional Information:", bg='#f0f0f0').grid(row=4, column=0, padx=10, pady=10)
additional_info_entry = tk.Entry(frame1, width=30)
additional_info_entry.grid(row=4, column=1, padx=10, pady=10)

next_button1 = tk.Button(frame1, text="Next", command=lambda: show_frame(frame2), bg='#4CAF50', fg='white')
next_button1.grid(row=5, columnspan=2, pady=20)

# Frame 2: Testing
tk.Label(frame2, text="Product Ready:", bg='#f0f0f0').grid(row=0, column=0, padx=10, pady=10)
product_ready_var = tk.StringVar()
product_ready_entry = tk.Entry(frame2, textvariable=product_ready_var, width=30)
product_ready_entry.grid(row=0, column=1, padx=10, pady=10)

tk.Label(frame2, text="Test Prepared:", bg='#f0f0f0').grid(row=1, column=0, padx=10, pady=10)
test_prepared_var = tk.StringVar()
test_prepared_entry = tk.Entry(frame2, textvariable=test_prepared_var, width=30)
test_prepared_entry.grid(row=1, column=1, padx=10, pady=10)

tk.Label(frame2, text="Product Released:", bg='#f0f0f0').grid(row=2, column=0, padx=10, pady=10)
product_released_var = tk.StringVar()
product_released_entry = tk.Entry(frame2, textvariable=product_released_var, width=30)
product_released_entry.grid(row=2, column=1, padx=10, pady=10)

next_button2 = tk.Button(frame2, text="Next", command=lambda: show_frame(frame3), bg='#4CAF50', fg='white')
next_button2.grid(row=3, columnspan=2, pady=20)

# Frame 3: Marketing
tk.Label(frame3, text="Knowledge Transfer:", bg='#f0f0f0').grid(row=0, column=0, padx=10, pady=10)
knowledge_transfer_var = tk.StringVar()
knowledge_transfer_menu = ttk.Combobox(frame3, textvariable=knowledge_transfer_var, state="readonly")
knowledge_transfer_menu['values'] = ("Online Meeting", "On-site Meeting")
knowledge_transfer_menu.grid(row=0, column=1, padx=10, pady=10)

tk.Label(frame3, text="Date:", bg='#f0f0f0').grid(row=1, column=0, padx=10, pady=10)
date_entry = tk.Entry(frame3, width=30)
date_entry.grid(row=1, column=1, padx=10, pady=10)

save_button = tk.Button(frame3, text="Save", command=save_data, bg='#4CAF50', fg='white')
save_button.grid(row=2, columnspan=2, pady=20)

# Start mit Frame 1
show_frame(frame1)

# Hauptschleife starten
root.mainloop()
